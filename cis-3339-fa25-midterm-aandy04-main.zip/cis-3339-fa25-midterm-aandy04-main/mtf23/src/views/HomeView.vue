<script setup>
import HelloWorld from '../components/HelloWorld.vue'
</script>

<template>
  <main>
    <div class="wrapper">
      <HelloWorld msg="You did it!" />
    </div>
  </main>
</template>
